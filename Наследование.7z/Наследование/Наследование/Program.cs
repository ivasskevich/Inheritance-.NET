﻿using System;
using System.IO;

public class Person
{
    protected string name;
    protected string surname;
    protected int age;
    protected string phone;

    public string Name
    {
        get => name;
        set => name = value;
    }

    public string Surname
    {
        get => surname;
        set => surname = value;
    }

    public int Age
    {
        get => age;
        set => age = value;
    }

    public string Phone
    {
        get => phone;
        set => phone = value;
    }

    public Person() { }

    public Person(string name, string surname, int age, string phone)
    {
        this.name = name;
        this.surname = surname;
        this.age = age;
        this.phone = phone;
    }

    public virtual void Print()
    {
        Console.WriteLine($"Name: {name}, Surname: {surname}, Age: {age}, Phone: {phone}");
    }
}

class Student : Person
{
    protected double average;
    protected int number_of_group;

    public double Average
    {
        get => average;
        set => average = value;
    }

    public int NumberOfGroup
    {
        get => number_of_group;
        set => number_of_group = value;
    }

    public Student() { }

    public Student(string name, string surname, int age, string phone, double average, int number_of_group)
        : base(name, surname, age, phone)
    {
        this.average = average;
        this.number_of_group = number_of_group;
    }

    public override void Print()
    {
        base.Print();
        Console.WriteLine($"Average: {average}, Group Number: {number_of_group}");
    }
}

class AcademyGroup
{
    private Student[] students;
    private int count;
    private const string filePath = "students.txt";

    public AcademyGroup()
    {
        students = new Student[100];
        count = 0;
        Load();
    }

    public void Add(Student student)
    {
        for (int i = 0; i < count; i++)
        {
            if (students[i].Name.Equals(student.Name, StringComparison.OrdinalIgnoreCase) &&
                students[i].Surname.Equals(student.Surname, StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine($"Student {student.Name} {student.Surname} already exists. Please use a different name.");
                return;
            }
        }

        if (count < students.Length)
        {
            students[count] = student;
            count++;
            Save();
        }
        else
        {
            Console.WriteLine("Cannot add more students, group is full.");
        }
    }

    public void Remove(string surname)
    {
        bool found = false;

        for (int i = 0; i < count; i++)
        {
            if (students[i].Surname.Equals(surname, StringComparison.OrdinalIgnoreCase))
            {
                found = true;
                for (int j = i; j < count - 1; j++)
                {
                    students[j] = students[j + 1];
                }
                students[count - 1] = null;
                count--;
                i--;
                Console.WriteLine($"Student {surname} removed successfully.");
            }
        }

        if (!found)
        {
            Console.WriteLine($"Student with surname {surname} not found.");
        }

        Save();
    }

    public void PrintFromFile()
    {
        if (!File.Exists(filePath))
        {
            Console.WriteLine("Data file not found.");
            return;
        }

        using (StreamReader reader = new StreamReader(filePath))
        {
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                var parts = line.Split(',');
                if (parts.Length == 6)
                {
                    var student = new Student(parts[0], parts[1], int.Parse(parts[2]), parts[3], double.Parse(parts[4]), int.Parse(parts[5]));
                    student.Print();
                    Console.WriteLine();
                }
                else
                {
                    Console.WriteLine($"Invalid student data in file: {line}. Expected 6 parts but found {parts.Length}.");
                }
            }
        }
    }

    public Student FindStudent(string surname)
    {
        foreach (var student in students)
        {
            if (student != null && student.Surname.Equals(surname, StringComparison.OrdinalIgnoreCase))
            {
                return student;
            }
        }
        return null;
    }

    public void EditStudent(string surname)
    {
        Student student = FindStudent(surname);
        if (student != null)
        {
            Console.Write("Enter new name (leave empty to keep current): ");
            string name = Console.ReadLine();
            if (!string.IsNullOrEmpty(name)) student.Name = name;

            Console.Write("Enter new surname (leave empty to keep current): ");
            string newSurname = Console.ReadLine();
            if (!string.IsNullOrEmpty(newSurname)) student.Surname = newSurname;

            Console.Write("Enter new age (leave empty to keep current): ");
            string ageInput = Console.ReadLine();
            if (int.TryParse(ageInput, out int newAge)) student.Age = newAge;

            Console.Write("Enter new phone (leave empty to keep current): ");
            string phone = Console.ReadLine();
            if (!string.IsNullOrEmpty(phone)) student.Phone = phone;

            Console.Write("Enter new average grade (leave empty to keep current): ");
            string averageInput = Console.ReadLine();
            if (double.TryParse(averageInput, out double newAverage)) student.Average = newAverage;

            Console.Write("Enter new group number (leave empty to keep current): ");
            string groupInput = Console.ReadLine();
            if (int.TryParse(groupInput, out int newGroup)) student.NumberOfGroup = newGroup;

            Console.WriteLine("Student information updated.");
            Save();
        }
        else
        {
            Console.WriteLine($"Student with surname {surname} not found.");
        }
    }

    private void Save()
    {
        using (StreamWriter writer = new StreamWriter(filePath))
        {
            for (int i = 0; i < count; i++)
            {
                writer.WriteLine($"{students[i].Name},{students[i].Surname},{students[i].Age},{students[i].Phone},{students[i].Average},{students[i].NumberOfGroup}");
            }
        }
    }

    private void Load()
    {
        if (File.Exists(filePath))
        {
            using (StreamReader reader = new StreamReader(filePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    var parts = line.Split(',');
                    if (parts.Length == 6)
                    {
                        var student = new Student(parts[0], parts[1], int.Parse(parts[2]), parts[3], double.Parse(parts[4]), int.Parse(parts[5]));
                        Add(student);
                    }
                }
            }
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        AcademyGroup group = new AcademyGroup();
        bool exit = false;

        while (!exit)
        {
            Console.WriteLine("Menu:");
            Console.WriteLine("1. Add student");
            Console.WriteLine("2. Remove student");
            Console.WriteLine("3. Print students");
            Console.WriteLine("4. Search student");
            Console.WriteLine("5. Edit student");
            Console.WriteLine("6. Exit");
            Console.Write("Select an option: ");
            string option = Console.ReadLine();

            switch (option)
            {
                case "1":
                    Console.Write("Enter name: ");
                    string name = Console.ReadLine();
                    Console.Write("Enter surname: ");
                    string surname = Console.ReadLine();
                    Console.Write("Enter age: ");
                    int age = int.Parse(Console.ReadLine());
                    Console.Write("Enter phone: ");
                    string phone = Console.ReadLine();
                    Console.Write("Enter average grade: ");
                    double average = double.Parse(Console.ReadLine());
                    Console.Write("Enter group number: ");
                    int groupNumber = int.Parse(Console.ReadLine());

                    var student = new Student(name, surname, age, phone, average, groupNumber);
                    group.Add(student);
                    break;

                case "2":
                    Console.Write("Enter surname of the student to remove: ");
                    string surnameToRemove = Console.ReadLine();
                    group.Remove(surnameToRemove);
                    break;

                case "3":
                    Console.WriteLine("List of students from file:");
                    group.PrintFromFile();
                    break;

                case "4":
                    Console.Write("Enter surname of the student to search: ");
                    string surnameToSearch = Console.ReadLine();
                    Student foundStudent = group.FindStudent(surnameToSearch);
                    if (foundStudent != null)
                    {
                        foundStudent.Print();
                    }
                    else
                    {
                        Console.WriteLine("Student not found.");
                    }
                    break;

                case "5":
                    Console.Write("Enter surname of the student to edit: ");
                    string surnameToEdit = Console.ReadLine();
                    group.EditStudent(surnameToEdit);
                    break;

                case "6":
                    exit = true;
                    break;

                default:
                    Console.WriteLine("Invalid option, please try again.");
                    break;
            }
        }
    }
}
